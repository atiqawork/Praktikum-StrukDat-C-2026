barang = ("B001", "Laptop Gaming", 15000000)
(kode, nama_barang, harga) = barang
print(harga)
x = list(barang)
stok = [15, 50, 30, 25, 40]
stok.append(100)
stok.insert(2, 75)
stok.sort(reverse = True)
print(stok)
rata = (15 + 25 + 30 + 40 + 50 + 75 + 100) / 7
print("List stok berisi ", stok, "dengan rata rata ", rata)